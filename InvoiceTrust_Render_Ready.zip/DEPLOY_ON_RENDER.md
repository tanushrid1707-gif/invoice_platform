# Deploy InvoiceTrust demo on Render

1. Extract this ZIP on your computer.
2. Create a GitHub repository and upload all files in this folder (not the ZIP itself).
3. Sign in to https://render.com and choose **New + → Blueprint** (or create a Web Service).
4. Connect the repository containing `render.yaml`.
5. Deploy. Render will give you a public `https://...onrender.com` URL.
6. Open the URL and test the demo flow. Render free services may sleep when idle, and local files/SQLite may not persist across redeploys/restarts unless you configure persistent storage.

## Important safety and production limitations

- This is a hackathon/demo MVP. The app uses fixed demo tokens and does not have production authentication. Do not upload real invoices, personal information, or confidential business documents to this public demo.
- Financing, disbursement, repayment and buyer histories are simulated. It is not connected to banks, GST/e-invoice systems, KYC, or credit bureaus.
- Before real use, add proper authentication and authorization, secure document storage, persistent database/storage, secrets management, rate limiting, and a security review.
- A matching hash proves a file has not changed since registration; it does not prove the invoice is genuine.
