#!/usr/bin/env python3
"""InvoiceTrust MVP - extraction, cross-checks, duplicate detection, risk, workflow,
hybrid audit (off-chain salted-hash documents + local hash-chained ledger). Python stdlib only."""
import base64, difflib, hashlib, io, json, os, re, secrets, sqlite3, threading, time
from datetime import datetime, date
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = os.path.dirname(os.path.abspath(__file__))
DB = os.environ.get("IT_DB", os.path.join(ROOT, "it.db"))
STORE = os.environ.get("IT_STORE", os.path.join(ROOT, "store"))
LOCK = threading.RLock()
# DEMO AUTH ONLY: static tokens. Production = OIDC/SSO + per-tenant keys.
USERS = {"tok-acme": ("acme", "applicant"), "tok-bolt": ("bolt", "applicant"),
         "tok-lender": ("lender1", "lender"), "tok-audit": ("auditor1", "auditor")}
DUP_T, DUP_DAYS, LOWCONF = 0.75, 14, 0.7
CRIT = ["invoice_no", "date", "seller", "buyer", "po_ref", "amount"]


class Err(Exception):
    def __init__(s, msg, code=400): super().__init__(msg); s.code = code


def sha(b): return hashlib.sha256(b).hexdigest()
def cj(o): return json.dumps(o, sort_keys=True, separators=(",", ":"))
def conn():
    c = sqlite3.connect(DB, timeout=30); c.row_factory = sqlite3.Row; return c


SCHEMA = """create table if not exists inv(id integer primary key autoincrement,owner,status,fields,conf,checks,dups,risk,reco,reasons,
 created real,proc_ms real,amount real,fp text);
create table if not exists doc(id integer primary key autoincrement,inv_id,kind,path,salt,h);
create table if not exists buyer(name primary key,credit_limit,outstanding,hist);
create table if not exists ledger(idx integer primary key,ts real,event,ref,payload,phash,prev,h);"""
BUYERS = [("Zenith Retail Ltd", 5_000_000, 800_000, [0, -2, 3, 0, 1, -1, 0, 2, -3, 0]),
          ("Orbit Motors Pvt Ltd", 2_000_000, 900_000, [5, 12, 0, 8, 20, 3, 15, 7]),
          ("Nimbus Traders", 1_000_000, 700_000, [30, 45, 12, 60, 25, 40])]  # SYNTHETIC histories


def init():
    os.makedirs(STORE, exist_ok=True)
    c = conn(); c.executescript(SCHEMA)
    if not c.execute("select 1 from buyer").fetchone():
        for n, l, o, h in BUYERS: c.execute("insert into buyer values(?,?,?,?)", (n, l, o, json.dumps(h)))
    c.commit(); c.close()


# ---------------- hybrid audit: local hash-chained permissioned ledger ----------------
def append(c, event, ref, payload):
    last = c.execute("select idx,h from ledger order by idx desc limit 1").fetchone()
    idx = last["idx"] + 1 if last else 0; prev = last["h"] if last else "0" * 64
    ts = round(time.time(), 3); p = cj(payload); ph = sha(p.encode())
    h = sha(f"{idx}|{ts}|{event}|{ref}|{ph}|{prev}".encode())
    c.execute("insert into ledger values(?,?,?,?,?,?,?,?)", (idx, ts, event, str(ref), p, ph, prev, h))


def verify():
    c = conn(); rep = {"chain_ok": True, "chain_errors": [], "docs": [], "blocks": 0, "head": None}; prev = "0" * 64
    for r in c.execute("select * from ledger order by idx"):
        e = []
        if r["prev"] != prev: e.append("link to previous block broken")
        if sha(r["payload"].encode()) != r["phash"]: e.append("payload altered after anchoring")
        if sha(f"{r['idx']}|{r['ts']}|{r['event']}|{r['ref']}|{r['phash']}|{r['prev']}".encode()) != r["h"]:
            e.append("block hash mismatch")
        if e: rep["chain_errors"].append({"block": r["idx"], "event": r["event"], "errors": e})
        prev = r["h"]; rep["blocks"] += 1; rep["head"] = r["h"]
    reg = {int(r["ref"]): json.loads(r["payload"])["hash"] for r in
           c.execute("select ref,payload from ledger where event='DOC_REGISTERED'")}
    for d in c.execute("select * from doc"):
        try: actual = sha(d["salt"].encode() + open(d["path"], "rb").read())
        except OSError: actual = None
        st = "MISSING" if actual is None else ("OK" if actual == reg.get(d["id"]) else "MODIFIED")
        rep["docs"].append({"doc": d["id"], "inv": d["inv_id"], "kind": d["kind"], "status": st,
                            "anchored": (reg.get(d["id"]) or "")[:16], "current": (actual or "")[:16]})
    rep["chain_ok"] = not rep["chain_errors"]
    rep["all_ok"] = rep["chain_ok"] and all(d["status"] == "OK" for d in rep["docs"])
    c.close(); return rep


# ---------------- extraction ----------------
ALIAS = {"invoice_no": ["invoice no", "invoice number", "inv #", "invoice #"], "date": ["date", "issued", "invoice date"],
         "seller": ["seller", "from", "supplier"], "buyer": ["buyer", "bill to", "customer"],
         "po_ref": ["po ref", "purchase order", "po no"], "amount": ["total", "amount due", "amount"]}


def to_text(name, data):
    n = name.lower()
    try:
        if n.endswith(".pdf"):
            from pypdf import PdfReader  # optional dependency
            return "\n".join(p.extract_text() or "" for p in PdfReader(io.BytesIO(data)).pages)
        if n.endswith((".png", ".jpg", ".jpeg")):
            import pytesseract; from PIL import Image  # optional OCR dependency
            return pytesseract.image_to_string(Image.open(io.BytesIO(data)))
    except Exception: return ""   # nothing extracted -> every field gets confidence 0 -> human entry
    return data.decode("utf8", "ignore")


def kv(t):
    d, items = {}, []
    for l in t.splitlines():
        l = l.strip()
        if l.startswith("- "): items.append(l[2:])
        elif ":" in l: k, v = l.split(":", 1); d.setdefault(k.strip().lower(), v.strip())
    return d, items


def pdate(s):
    for f in ("%Y-%m-%d", "%d %b %Y", "%d/%m/%Y"):
        try: return datetime.strptime((s or "").strip(), f).date().isoformat()
        except ValueError: pass


def pnum(s):
    m = re.search(r"\d[\d,]*(?:\.\d+)?", str(s or "")); return float(m.group().replace(",", "")) if m else None


def extract(text):
    d, items = kv(text); f, cf = {}, {}
    for k, al in ALIAS.items():
        for i, a in enumerate(al):
            if a in d:
                v = d[a]; ok = True
                if k == "date": v = pdate(v); ok = v is not None
                elif k == "amount": v = pnum(v); ok = v is not None
                f[k] = v; cf[k] = (0.98 if i == 0 else 0.88) if ok else 0.3; break
        else: f[k], cf[k] = None, 0.0
    f["items"] = items; return f, cf


# ---------------- cross-checks ----------------
def nm(s):
    s = re.sub(r"[^a-z0-9 ]", "", (s or "").lower()); return " ".join(w for w in s.split() if w not in ("pvt", "ltd", "llp", "limited", "private", "inc"))
def same(a, b): return bool(a and b) and difflib.SequenceMatcher(None, nm(a), nm(b)).ratio() >= 0.9
ACTION = {"amount_vs_po": "Confirm the invoice total, or upload a corrected invoice/PO.",
          "delivery_evidence": "Upload a signed delivery receipt.",
          "delivery_quantity": "Finance only the delivered portion, or provide proof of the remaining delivery.",
          "po_ref": "Check the PO reference printed on the invoice and the delivery receipt.",
          "buyer_vs_po": "Confirm the buyer legal name.", "seller_vs_po": "Confirm the seller legal name.",
          "date_vs_po": "Invoice predates its PO: confirm dates.", "po_present": "Upload the purchase order.",
          "contract_cap": "Invoice exceeds contract ceiling: attach an amendment.", "contract_parties": "Contract parties differ from the invoice."}


def crosscheck(f, po, dl, ct):
    C = []
    def add(n, s, d): C.append({"check": n, "status": s, "detail": d})
    if not po: add("po_present", "fail", "No purchase order supplied")
    else:
        pa = pnum(po.get("total"))
        if pa and f["amount"] is not None:
            dv = abs(f["amount"] - pa) / pa
            add("amount_vs_po", "pass" if dv <= .01 else "fail", f"Invoice {f['amount']:,.2f} vs PO {pa:,.2f} ({dv:.1%} difference)")
        add("buyer_vs_po", "pass" if same(f["buyer"], po.get("buyer")) else "fail", f"Invoice buyer '{f['buyer']}' vs PO '{po.get('buyer')}'")
        add("seller_vs_po", "pass" if same(f["seller"], po.get("seller")) else "fail", f"Invoice seller '{f['seller']}' vs PO '{po.get('seller')}'")
        if f["po_ref"]: add("po_ref", "pass" if f["po_ref"].strip() == po.get("po no", "").strip() else "fail", f"Invoice cites {f['po_ref']}, PO is {po.get('po no')}")
        a, b = f["date"], pdate(po.get("date"))
        if a and b: add("date_vs_po", "pass" if a >= b else "fail", f"Invoice {a}, PO {b}")
    if not dl: add("delivery_evidence", "fail", "No delivery receipt supplied")
    else:
        dq, pq = pnum(dl.get("quantity delivered")), pnum((po or {}).get("quantity"))
        if dq is not None and pq: add("delivery_quantity", "pass" if dq >= pq else "fail", f"Delivered {dq:g} of {pq:g} ordered units")
        if po and dl.get("po ref") and dl["po ref"].strip() != po.get("po no", "").strip(): add("po_ref", "fail", f"Receipt cites {dl['po ref']}, PO is {po.get('po no')}")
        dd = pdate(dl.get("delivered"))
        if dd and f["date"] and dd > f["date"]: add("delivered_after_invoice", "warn", f"Delivery {dd} is after invoice date {f['date']}")
        add("delivery_signed", "pass" if dl.get("received by") else "warn", f"Received by: {dl.get('received by') or 'blank'}")
    if ct:
        cap = pnum(ct.get("max invoice value"))
        if cap and f["amount"] is not None: add("contract_cap", "pass" if f["amount"] <= cap else "fail", f"Invoice {f['amount']:,.0f} vs contract ceiling {cap:,.0f}")
        p = nm(ct.get("parties")); ok = nm(f["seller"]) in p and nm(f["buyer"]) in p if f["seller"] and f["buyer"] else False
        add("contract_parties", "pass" if ok else "fail", f"Contract parties: {ct.get('parties')}")
    else: add("contract", "warn", "No contract supplied")
    return C


# ---------------- duplicate detection (only across participating data in THIS system) ----------------
def words(f): return set(re.findall(r"[a-z]+", " ".join(f.get("items") or []).lower()))
def gap(a, b):
    try: return abs((date.fromisoformat(a) - date.fromisoformat(b)).days)
    except Exception: return 999


def find_dups(c, f, fp, self_id):
    out = []
    for r in c.execute("select id,fields,fp from inv where id!=?", (self_id,)):
        g = json.loads(r["fields"])
        if r["fp"] == fp: out.append({"id": r["id"], "score": 1.0, "kind": "exact_file", "flag": True, "reasons": ["Byte-identical file already submitted"]}); continue
        a, b = words(f), words(g); jac = len(a & b) / len(a | b) if a | b else 0
        am = 0.0
        if f["amount"] and g["amount"]: am = max(0, 1 - abs(f["amount"] - g["amount"]) / max(f["amount"], g["amount"]) * 20)
        d = gap(f["date"] or "", g["date"] or ""); dt = max(0, 1 - d / DUP_DAYS)
        sl, by = same(f["seller"], g["seller"]), same(f["buyer"], g["buyer"])
        score = .35 * jac + .3 * am + .15 * dt + .1 * by + .1 * sl
        why = [f"line-item overlap {jac:.0%}", f"amount within {abs((f['amount'] or 0) - (g['amount'] or 0)):,.0f}", f"{d if d < 999 else '?'} days apart", f"same seller/buyer: {sl}/{by}"]
        if f["invoice_no"] and f["invoice_no"] == g["invoice_no"] and sl:
            out.append({"id": r["id"], "score": max(score, .95), "kind": "same_invoice_no", "flag": True, "reasons": ["Same invoice number from same seller"] + why})
        elif score >= DUP_T:
            out.append({"id": r["id"], "score": round(score, 3), "kind": "near_duplicate" if d <= DUP_DAYS else "recurring_pattern",
                        "flag": d <= DUP_DAYS, "reasons": why + ([] if d <= DUP_DAYS else ["looks like a recurring order, informational only"])})
    return sorted(out, key=lambda x: -x["score"])


# ---------------- repayment risk (separate from document verification) ----------------
def risk(c, f):
    b = next((r for r in c.execute("select * from buyer") if f.get("buyer") and same(r["name"], f["buyer"])), None)
    if not b or f.get("amount") is None:
        return {"score": 60, "band": "medium", "decline": False, "factors": [{"factor": "thin_file", "points": 60, "why": "No payment history for this buyer in participating data"}]}
    h = json.loads(b["hist"]); late = [x for x in h if x > 0]; avg = sum(late) / len(late) if late else 0
    util = (b["outstanding"] + f["amount"]) / b["credit_limit"]
    F = [{"factor": "late_payment_rate", "points": round(40 * len(late) / len(h)), "why": f"{len(late)} of {len(h)} past invoices paid late"},
         {"factor": "average_delay", "points": round(min(30, avg / 1.5)), "why": f"average {avg:.0f} days late when late"},
         {"factor": "receivables_exposure", "points": round(30 * min(1, util)), "why": f"open receivables + this invoice = {util:.0%} of buyer credit limit"}]
    s = sum(x["points"] for x in F)
    return {"score": s, "band": "low" if s < 30 else "medium" if s < 55 else "high", "decline": s >= 75 or util > 1, "factors": F, "buyer": b["name"]}


def recommend(f, rk, ct):
    if rk["decline"]: return {"decision": "decline", "why": "Buyer repayment risk too high or exposure above limit", "simulated": True}
    pct = {"low": .9, "medium": .8, "high": .65}[rk["band"]]
    m = re.search(r"net\s*(\d+)", (ct or {}).get("payment terms", ""), re.I); tenor = int(m.group(1)) if m else 45
    return {"decision": "offer", "advance_pct": pct, "advance": round(f["amount"] * pct, 2),
            "fee": round(f["amount"] * pct * .012 * tenor / 30, 2), "tenor_days": tenor, "simulated": True}


# ---------------- workflow ----------------
def load_support(c, iid):
    s = {}
    for d in c.execute("select kind,path from doc where inv_id=? and kind!='invoice'", (iid,)):
        raw = open(d["path"], "rb").read(); s[d["kind"]] = kv(to_text(d["path"], raw))[0]
    return s


def evaluate(c, iid):
    r = c.execute("select * from inv where id=?", (iid,)).fetchone()
    f, cf = json.loads(r["fields"]), json.loads(r["conf"]); s = load_support(c, iid)
    checks = crosscheck(f, s.get("po"), s.get("delivery"), s.get("contract"))
    dups = find_dups(c, f, r["fp"], iid); rk = risk(c, f) if f["amount"] is not None else None
    reasons = [f"{x['detail']}. {ACTION.get(x['check'], 'Review manually.')}" for x in checks if x["status"] == "fail"]
    reasons += [f"Low extraction confidence for '{k}' ({cf[k]:.2f}): confirm or correct it." for k in CRIT if cf.get(k, 0) < LOWCONF]
    reasons += [f"Possible duplicate of invoice #{d['id']} (score {d['score']}): {'; '.join(d['reasons'][:2])}. Confirm it was not financed already." for d in dups if d["flag"]]
    blocked = any(d["kind"] in ("exact_file", "same_invoice_no") for d in dups)
    status = "BLOCKED_DUPLICATE" if blocked else "NEEDS_REVIEW" if reasons else "VERIFIED"
    reco = recommend(f, rk, s.get("contract")) if status == "VERIFIED" and rk else None
    c.execute("update inv set status=?,checks=?,dups=?,risk=?,reco=?,reasons=?,amount=? where id=?",
              (status, cj(checks), cj(dups), cj(rk), cj(reco), cj(reasons), f["amount"], iid))
    append(c, "VERIFICATION_RESULT", iid, {"inv": iid, "status": status, "failed_checks": sum(x["status"] == "fail" for x in checks),
                                           "dup_flags": sum(d["flag"] for d in dups), "risk_band": (rk or {}).get("band")})
    return status


def submit(owner, files):
    """files: {kind: (filename, bytes)} kinds: invoice, po, delivery, contract"""
    t0 = time.perf_counter()
    if "invoice" not in files: raise Err("invoice file required")
    with LOCK:
        c = conn(); name, raw = files["invoice"]
        f, cf = extract(to_text(name, raw))
        iid = c.execute("insert into inv(owner,status,fields,conf,created,fp) values(?,?,?,?,?,?)",
                        (owner, "SUBMITTED", cj(f), cj(cf), time.time(), sha(raw))).lastrowid
        for kind, (fn, data) in files.items():
            salt = secrets.token_hex(8); path = os.path.join(STORE, f"{iid}_{kind}_{re.sub(r'[^A-Za-z0-9._-]', '_', fn)}")
            open(path, "wb").write(data); h = sha(salt.encode() + data)
            did = c.execute("insert into doc(inv_id,kind,path,salt,h) values(?,?,?,?,?)", (iid, kind, path, salt, h)).lastrowid
            append(c, "DOC_REGISTERED", did, {"inv": iid, "kind": kind, "hash": h})  # hash only; salted so docs can't be guessed
        append(c, "INVOICE_SUBMITTED", iid, {"inv": iid, "owner": owner})
        st = evaluate(c, iid)
        c.execute("update inv set proc_ms=? where id=?", ((time.perf_counter() - t0) * 1000, iid))
        c.commit(); c.close(); return iid, st


def view(c, r, role):
    d = {k: r[k] for k in ("id", "owner", "status", "amount", "created", "proc_ms")}
    d["docs"] = [dict(x) for x in c.execute("select id,kind,h from doc where inv_id=?", (r["id"],))]
    L = lambda k: json.loads(r[k]) if r[k] else None
    if role == "auditor":   # auditors see process evidence, not business content
        d["amount"] = None; d["checks"] = [{"check": x["check"], "status": x["status"]} for x in L("checks") or []]
        d["dup_flags"] = sum(x["flag"] for x in L("dups") or [])
    else: d.update(fields=L("fields"), conf=L("conf"), checks=L("checks"), dups=L("dups"), risk=L("risk"), reco=L("reco"), reasons=L("reasons"))
    return d


def get_inv(c, iid, name, role):
    r = c.execute("select * from inv where id=?", (iid,)).fetchone()
    if not r: raise Err("not found", 404)
    if role == "applicant" and r["owner"] != name: raise Err("not your invoice", 403)
    return r


def api(m, p, u, b):
    name, role = u; P = p.strip("/").split("/")[1:]
    if m == "POST" and P == ["demo", "reset"]:   # DEMO ONLY
        import shutil, synth; shutil.rmtree(STORE, ignore_errors=True)
        if os.path.exists(DB): os.remove(DB)
        init(); synth.seed_demo(); return {"ok": True}
    c = conn()
    try:
        out = _api(c, m, P, name, role, b); c.commit(); return out
    finally: c.close()


def _api(c, m, P, name, role, b):
    if m == "GET" and P == ["me"]: return {"user": name, "role": role}
    if m == "GET" and P == ["invoices"]:
        rows = c.execute("select * from inv order by id desc" if role != "applicant" else "select * from inv where owner=? order by id desc", () if role != "applicant" else (name,))
        return [view(c, r, role) for r in rows]
    if m == "GET" and P[0] == "invoice": return view(c, get_inv(c, int(P[1]), name, role), role)
    if m == "POST" and P == ["submit"]:
        if role != "applicant": raise Err("only applicants submit", 403)
        fl = {k: (v["name"], base64.b64decode(v["b64"])) for k, v in b["files"].items() if v}
        iid, st = submit(name, fl); return {"id": iid, "status": st}
    if m == "POST" and len(P) == 3 and P[0] == "invoice":
        r = get_inv(c, int(P[1]), name, role); iid, act = r["id"], P[2]
        if act == "correct":
            if role == "auditor" or r["status"] not in ("NEEDS_REVIEW",): raise Err("not allowed in this state", 403)
            f, cf = json.loads(r["fields"]), json.loads(r["conf"]); ch = []
            for k, v in b["fields"].items():
                if k in CRIT and v not in (None, ""):
                    nv = pnum(v) if k == "amount" else (pdate(v) or v) if k == "date" else v
                    if nv != f.get(k): f[k] = nv; cf[k] = 1.0; ch.append(k)
            c.execute("update inv set fields=?,conf=? where id=?", (cj(f), cj(cf), iid))
            append(c, "FIELDS_CORRECTED", iid, {"inv": iid, "fields": ch, "by": role}); evaluate(c, iid)
        elif act == "review":
            if role != "lender" or r["status"] not in ("NEEDS_REVIEW", "BLOCKED_DUPLICATE"): raise Err("lender review of flagged invoices only", 403)
            ok = b["decision"] == "approve" and r["status"] == "NEEDS_REVIEW"
            f = json.loads(r["fields"]); rk = json.loads(r["risk"]) if r["risk"] else None
            reco = recommend(f, rk, load_support(c, iid).get("contract")) if ok and rk else None
            c.execute("update inv set status=?,reco=? where id=?", ("APPROVED" if ok else "REJECTED", cj(reco), iid))
            append(c, "REVIEW_DECISION", iid, {"inv": iid, "decision": "approve" if ok else "reject", "note_hash": sha(b.get("note", "").encode())})
        elif act == "disburse":
            reco = json.loads(r["reco"]) if r["reco"] else None
            if role != "lender" or r["status"] not in ("VERIFIED", "APPROVED") or not reco or reco["decision"] != "offer": raise Err("needs lender + approved offer", 403)
            f = json.loads(r["fields"]); c.execute("update inv set status='DISBURSED' where id=?", (iid,))
            for x in c.execute("select name from buyer").fetchall():
                if same(x["name"], f["buyer"]): c.execute("update buyer set outstanding=outstanding+? where name=?", (f["amount"], x["name"]))
            append(c, "DISBURSED_SIMULATED", iid, {"inv": iid, "advance": reco["advance"]})
        elif act == "repay":
            if r["status"] != "DISBURSED" or role == "auditor": raise Err("only disbursed invoices can be repaid", 403)
            f = json.loads(r["fields"]); late = int(b.get("days_late", 0))
            for x in c.execute("select * from buyer").fetchall():
                if same(x["name"], f["buyer"]):
                    h = json.loads(x["hist"]) + [late]; c.execute("update buyer set outstanding=max(0,outstanding-?),hist=? where name=?", (f["amount"], cj(h), x["name"]))
            c.execute("update inv set status='REPAID' where id=?", (iid,)); append(c, "REPAYMENT_SIMULATED", iid, {"inv": iid, "days_late": late})
        else: raise Err("unknown action", 404)
        return view(c, c.execute("select * from inv where id=?", (iid,)).fetchone(), role)
    if m == "GET" and P[0] == "doc":
        d = c.execute("select * from doc where id=?", (int(P[1]),)).fetchone()
        if not d: raise Err("not found", 404)
        get_inv(c, d["inv_id"], name, role)
        if role == "auditor": raise Err("auditors verify hashes; they cannot open documents", 403)
        append(c, "DOC_ACCESSED", d["id"], {"inv": d["inv_id"], "role": role, "by": name})
        return {"kind": d["kind"], "text": open(d["path"], "rb").read().decode("utf8", "ignore")}
    if m == "GET" and P == ["ledger"]:
        rows = [dict(r) for r in c.execute("select idx,ts,event,ref,payload,h,prev from ledger order by idx desc limit 200")]
        if role == "applicant":
            mine = {r["id"] for r in c.execute("select id from inv where owner=?", (name,))}
            rows = [r for r in rows if json.loads(r["payload"]).get("inv") in mine]
        return rows
    if m == "GET" and P == ["verify"]: c.commit(); return verify()
    if m == "GET" and P == ["metrics"]:
        fp = os.path.join(ROOT, "metrics.json"); return json.load(open(fp)) if os.path.exists(fp) else {"error": "run: python synth.py eval"}
    if P[:1] == ["demo"] and m == "POST":   # DEMO ONLY
        if P[1] == "tamper":
            if b["target"] == "doc":
                d = c.execute("select path from doc where id=?", (int(b["id"]),)).fetchone(); raw = open(d["path"], "rb").read()
                open(d["path"] + ".orig", "wb").write(raw); open(d["path"], "wb").write(re.sub(rb"(Total[^:\n]*:\s*(?:INR|Rs\.?)?\s*)(\d)", rb"\g<1>9\2", raw, count=1))
            else:
                c.execute("update ledger set payload=replace(payload,'\"status\":\"VERIFIED\"','\"status\":\"APPROVED\"') where idx=?", (int(b["id"]),))
            return {"ok": True}
        if P[1] == "restore":
            for d in c.execute("select path from doc"):
                if os.path.exists(d["path"] + ".orig"): os.replace(d["path"] + ".orig", d["path"])
            return {"ok": True}
    raise Err("no such route", 404)


class H(BaseHTTPRequestHandler):
    def log_message(s, *a): pass
    def send(s, code, obj, ct="application/json"):
        b = obj if isinstance(obj, bytes) else json.dumps(obj).encode()
        s.send_response(code); s.send_header("Content-Type", ct); s.send_header("Content-Length", str(len(b))); s.end_headers(); s.wfile.write(b)
    def do_GET(s): s.route("GET")
    def do_POST(s): s.route("POST")
    def route(s, m):
        p = s.path.split("?")[0]
        if m == "GET" and p in ("/", "/index.html"): return s.send(200, open(os.path.join(ROOT, "index.html"), "rb").read(), "text/html")
        u = USERS.get(s.headers.get("X-Token", ""))
        if not u: return s.send(401, {"error": "missing or invalid X-Token"})
        try:
            body = json.loads(s.rfile.read(int(s.headers.get("Content-Length", 0))) or b"{}") if m == "POST" else {}
            with LOCK: r = api(m, p, u, body)
            s.send(200, r)
        except Err as e: s.send(e.code, {"error": str(e)})
        except Exception as e: s.send(500, {"error": repr(e)})


if __name__ == "__main__":
    init()
    if not conn().execute("select 1 from inv").fetchone():
        import synth; synth.seed_demo()
    host = "0.0.0.0"
    port = int(os.environ.get("PORT", "8000"))
    print(f"InvoiceTrust listening on {host}:{port}")
    ThreadingHTTPServer((host, port), H).serve_forever()
