# InvoiceTrust: verifiable invoice financing for SMEs (SYNESIS 26, Problem 2)

Two questions, kept separate: **Is this paperwork consistent and new?** (document verification) and **Will the buyer pay?** (repayment risk).
Lenders see both with reasons. SMEs get clear next steps. Auditors can prove nothing was altered without reading business documents.

## Run (Python 3.9+, no installs needed)
    python synth.py eval          # measure; writes metrics.json
    python -m unittest -q         # 10 tests
    python invoicetrust.py        # http://127.0.0.1:8000  (seeds 4 demo invoices)
Optional: `pip install pypdf` (PDF text layer), `pytesseract pillow` + Tesseract (images). Without them, PDF/image fields get confidence 0 and the applicant types them in.
Demo logins are the dropdown in the UI (static tokens, demo only).

## Architecture
    Browser (role-based UI) -> HTTP JSON API (stdlib) -> engine
      extract (labels, aliases, confidence) -> cross-check (PO / delivery / contract)
      -> duplicate search -> risk (buyer history) -> workflow state machine
    Off-chain : documents on disk, access-controlled, each stored with a random salt
    "On-chain": hash-chained ledger (SQLite table). Each block = sha256(index|time|event|ref|payload_hash|prev_hash).
                 Ledger holds ONLY salted document hashes + event metadata, never document content.
    Verify    : recompute every block link + every file hash against the ledger.
Ledger is a **single-node local permissioned chain**, not a public blockchain. `append()` is the one seam to swap for an EVM testnet/consortium contract (emit the same hashes as events). Nothing here runs on a testnet today.

## Workflow
SUBMITTED -> VERIFIED | NEEDS_REVIEW | BLOCKED_DUPLICATE -> (human correction / lender review) -> APPROVED -> offer (simulated) -> DISBURSED (simulated) -> REPAID (simulated). Every transition is a ledger event.

## Detection logic
- **Extraction**: label-based parser; 0.98 for canonical labels, 0.88 for aliases, 0.3 for unparseable, 0 when absent. Fields under 0.7 force human review.
- **Cross-checks**: amount (1% tolerance), buyer/seller names, PO reference, dates, delivered vs ordered quantity, receipt present/signed, contract ceiling and parties.
- **Duplicates**: byte-identical file; same seller + invoice number; otherwise weighted score (line-item word overlap .35, amount .30, date proximity .15, buyer .10, seller .10, flag at >= 0.75 and <= 14 days). Same goods more than 14 days later = "recurring order", informational only.
- **Risk** (0-100): late-payment rate (40) + average delay (30) + receivables exposure vs credit limit (30). Each factor is shown. Decline at >= 75 or over limit.

## Honest limits
- A matching hash proves a file is unchanged since registration, **not** that the invoice is genuine or the goods exist. Authenticity needs the buyer's confirmation / e-invoice registry / GST / bank integrations (not built).
- Duplicates are found only among invoices submitted to this system. Cross-lender detection needs a shared registry (the deployment roadmap).
- Truncating the newest ledger blocks is undetectable unless the head hash is anchored externally (roadmap: publish the head to a testnet or auditor).
- Financing, fees, disbursement, repayment, buyer histories are **synthetic/simulated**. No bank, KYC, credit-bureau or e-invoice integration exists.
- Metrics come from our own text templates; real scanned documents will score lower. OCR path unmeasured.

## Measured results (python synth.py eval, seed 7, 83 invoices)
See metrics.json. Highlights: field accuracy 98.8% (amount 92.7%; all 4 errors flagged low-confidence), duplicates precision 1.00 / recall 0.90 / FPR 0.00 (2 disguised duplicates with price drift missed), cross-check 9/9 inconsistencies caught with 0/27 false alarms, median processing 3.5 ms.

## 3-minute pitch
**0:00 Problem.** SMEs wait 60+ days for payment; lenders lose money to duplicate and manipulated invoices and spend days on manual checks.
**0:30 Valid application** (invoice 1): upload invoice, PO, receipt, contract; extraction with confidence bars, all checks green, separate risk score with reasons, simulated offer in seconds. *Maps to: extraction, cross-checks, risk, workflow. Result: 98.8% field accuracy, 3.5 ms median. Benefit: faster funding.*
**1:00 Disguised duplicate** (invoice 2): new number, new template, shifted date, reordered lines; still flagged against #1 with reasons. *Result: precision 1.00, recall 0.90, FPR 0.00. Benefit: fewer double-financed invoices, and recurring orders aren't wrongly blocked.*
**1:30 Delivery mismatch** (invoice 3): 60% delivered, invoiced for 100%; actionable message tells the SME what to upload. *Result: 9/9 inconsistencies caught, 0/27 false alarms. Benefit: disputes caught before cash goes out.*
**2:00 Tamper test** (Audit tab): raise an invoice total on disk, verification shows MODIFIED; edit a ledger record, chain breaks. Auditor opens none of the documents. *Benefit: tamper-evident trail without exposing sensitive files.*
**2:30 Honesty and roadmap.** Hashes prove integrity, not authenticity; duplicates only within participating sources; financing is simulated. Next: pilot with one lender.

## Deployment roadmap
1. **0-3 months**: pilot with one lender on real (consented) invoices; PDF/OCR extraction with layout models; measure on real data; Postgres + object storage with encryption.
2. **3-6 months**: e-invoice/GST, accounting-software and buyer-confirmation integrations; real KYC/SSO; per-tenant keys.
3. **6-12 months**: consortium chain or testnet anchoring with external head publication; shared duplicate registry across lenders using privacy-preserving fingerprints; regulatory and security review before any live disbursement.
