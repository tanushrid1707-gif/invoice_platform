#!/usr/bin/env python3
"""Synthetic invoices + support docs, demo seeding, and the measurement harness.
usage: python synth.py eval   -> writes metrics.json (measured, nothing hard-coded)"""
import json, os, random, shutil, sys, tempfile
from datetime import date, timedelta
import invoicetrust as it

CAT = ["cotton fabric roll", "denim bolt", "zip fasteners", "polyester thread", "brass buttons", "woven labels",
       "packing cartons", "dye concentrate", "elastic bands", "lining cloth", "embroidery thread", "leather patches"]
SELLERS = ["Acme Textiles Pvt Ltd", "Bolt Components LLP"]
BUYERS = [b[0] for b in it.BUYERS]
MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def ind(n):  # Indian digit grouping
    s = f"{int(n)}"; head, tail = s[:-3], s[-3:]
    while len(head) > 2: tail = head[-2:] + "," + tail; head = head[:-2]
    return (head + "," if head else "") + tail + ".00"


def invoice_text(t, no, d, seller, buyer, po, items, amt, unknown_total=False):
    it_lines = "\n".join(f"- {n} x {q} @ {p}" for n, q, p in items)
    dd = d.isoformat() if t != 1 else f"{d.day:02d} {MON[d.month - 1]} {d.year}"
    tot = {0: f"Total: {amt:.2f}", 1: f"Amount Due: Rs. {ind(amt)}", 2: f"Total: INR {amt:,.0f}"}[t]
    if unknown_total: tot = f"Grand Total Payable: {amt:.2f}"      # unseen label -> must be low-confidence/missing
    if t == 0: return f"INVOICE\nInvoice No: {no}\nDate: {dd}\nSeller: {seller}\nBuyer: {buyer}\nPO Ref: {po}\nItems:\n{it_lines}\n{tot}\n"
    if t == 1: return f"TAX INVOICE\nInv #: {no}\nIssued: {dd}\nFrom: {seller}\nBill To: {buyer}\nPurchase Order: {po}\n{it_lines}\n{tot}\n"
    return f"Invoice Number: {no}\nDate: {dd}\nSeller: {seller}\nBuyer: {buyer}\nPO Ref: {po}\n{tot}\n{it_lines}\n"


def pick_items(r, k=3):
    return [(n, r.randint(50, 400), r.randint(20, 150)) for n in r.sample(CAT, k)]


def build(r, i, seller, buyer, d, items=None, t=None, no=None, po=None, flaw=None, unknown_total=False):
    items = items or pick_items(r); amt = sum(q * p for _, q, p in items); qty = sum(q for _, q, _ in items)
    no = no or f"INV-{1000 + i}"; po = po or f"PO-{5000 + i}"; t = r.randint(0, 2) if t is None else t
    po_amt, dq = amt, qty
    if flaw == "po_amount": po_amt = round(amt * 0.93)
    if flaw == "short_delivery": dq = round(qty * .6)
    pod = d - timedelta(days=r.randint(10, 30)); dld = d - timedelta(days=r.randint(1, 5))
    files = {"invoice": (f"{no}.txt", invoice_text(t, no, d, seller, buyer, po, items, amt, unknown_total).encode()),
             "po": ("po.txt", f"PURCHASE ORDER\nPO No: {po}\nDate: {pod}\nBuyer: {buyer}\nSeller: {seller}\nQuantity: {qty}\nTotal: {po_amt}\n".encode()),
             "contract": ("contract.txt", f"CONTRACT\nParties: {seller} and {buyer}\nMax Invoice Value: 2000000\nPayment Terms: Net 45\n".encode())}
    if flaw != "no_delivery":
        files["delivery"] = ("grn.txt", f"DELIVERY RECEIPT\nPO Ref: {po}\nDelivered: {dld}\nReceived By: Stores Manager\nQuantity Delivered: {dq}\n".encode())
    truth = {"invoice_no": no, "date": d.isoformat(), "seller": seller, "buyer": buyer, "po_ref": po, "amount": float(amt)}
    return files, truth, dict(items=items, seller=seller, buyer=buyer, d=d, amt=amt)


def disguise(r, i, meta, drift=False):
    items = list(meta["items"]); r.shuffle(items)
    if drift: items[0] = (items[0][0], items[0][1], items[0][2] + (1 if r.random() < .5 else 0))   # tiny price tweak
    items = [(n + (" (pcs)" if k == 0 and r.random() < .5 else ""), q, p) for k, (n, q, p) in enumerate(items)]
    return build(r, i, meta["seller"], meta["buyer"], meta["d"] + timedelta(days=r.randint(-3, 3)), items=items,
                 no=f"X{r.randint(10000, 99999)}-A", po=f"PO-{7000 + i}")


def seed_demo():
    r = random.Random(11); d = date.today() - timedelta(days=12)
    v, _, meta = build(r, 1, SELLERS[0], BUYERS[0], d, t=0); it.submit("acme", v)                                       # 1 valid
    dup, _, _ = disguise(r, 2, meta); dup["invoice"] = (dup["invoice"][0], dup["invoice"][1].replace(b"INVOICE", b"TAX INVOICE")); it.submit("acme", dup)  # 2 disguised duplicate
    mm, _, _ = build(r, 3, SELLERS[1], BUYERS[1], d, t=1, flaw="short_delivery"); it.submit("bolt", mm)                   # 3 delivery mismatch
    lo, _, _ = build(r, 4, SELLERS[1], BUYERS[2], d, t=2, unknown_total=True); it.submit("bolt", lo)                      # 4 unreadable total -> human correction


def evaluate():
    r = random.Random(7); tmp = tempfile.mkdtemp(); it.DB = os.path.join(tmp, "e.db"); it.STORE = os.path.join(tmp, "s"); it.init()
    base = date(2026, 3, 1); cases = []   # (files, truth, is_dup, kind, inconsistent)
    metas = []
    for i in range(40):
        flaw = ["po_amount", "short_delivery", "no_delivery"][i % 3] if i < 9 else None
        f, t, m = build(r, i, SELLERS[i % 2], BUYERS[i % 3], base + timedelta(days=i * 3), flaw=flaw, unknown_total=(i % 10 == 9))
        cases.append((f, t, False, "base", flaw is not None)); metas.append(m)
    n = 100
    for k in range(15):   # disguised duplicates (new number, template, dates, ordering, small drift)
        f, t, _ = disguise(r, n + k, metas[9 + k], drift=k % 3 == 0); cases.append((f, t, True, "disguised", False))
    for k in range(5): cases.append((dict(cases[10 + k][0]), cases[10 + k][1], True, "exact", False))
    for k in range(15):   # hard negatives: same parties, close dates, different goods
        m = metas[k]; f, t, _ = build(r, 200 + k, m["seller"], m["buyer"], m["d"] + timedelta(days=r.randint(2, 9))); cases.append((f, t, False, "hard_neg", False))
    for k in range(8):    # legit recurring orders: same goods, >14 days later
        m = metas[20 + k]; f, t, _ = build(r, 300 + k, m["seller"], m["buyer"], m["d"] + timedelta(days=30), items=m["items"]); cases.append((f, t, False, "recurring", False))
    tp = fp = tn = fn = 0; ft = {k: [0, 0] for k in it.CRIT}; lowflag = silent = wrong = 0; times = []
    inc_hit = inc_n = clean_alarm = clean_n = 0; errs = []
    c = it.conn()
    for files, truth, is_dup, kind, inconsistent in cases:
        iid, st = it.submit("acme", files); row = c.execute("select * from inv where id=?", (iid,)).fetchone()
        f, cf = json.loads(row["fields"]), json.loads(row["conf"]); times.append(row["proc_ms"])
        flagged = any(d["flag"] for d in json.loads(row["dups"]))
        tp += flagged and is_dup; fp += flagged and not is_dup; tn += (not flagged) and not is_dup; fn += (not flagged) and is_dup
        if is_dup and not flagged: errs.append(kind)
        if kind in ("base", "disguised"):   # extraction accuracy measured on first-time and altered-format docs
            for k in it.CRIT:
                ok = f[k] == truth[k]; ft[k][0] += ok; ft[k][1] += 1
                if not ok: wrong += 1; lowflag += cf[k] < it.LOWCONF; silent += cf[k] >= it.LOWCONF
        if kind == "base":
            fails = any(x["status"] == "fail" for x in json.loads(row["checks"]))
            if inconsistent: inc_n += 1; inc_hit += fails
            elif f["amount"] is not None: clean_n += 1; clean_alarm += fails
    tot = sum(v[1] for v in ft.values()); good = sum(v[0] for v in ft.values()); times.sort()
    prec = tp / (tp + fp) if tp + fp else None; rec = tp / (tp + fn) if tp + fn else None
    m = {"dataset": {"invoices": len(cases), "disguised_dups": 15, "exact_dups": 5, "hard_negatives": 15, "recurring_legit": 8, "baseline_unique": 40, "seed": 7},
         "extraction": {"field_accuracy": round(good / tot, 4), "per_field": {k: round(v[0] / v[1], 3) for k, v in ft.items()},
                        "wrong_fields": wrong, "wrong_flagged_low_confidence": lowflag, "silent_errors": silent},
         "duplicates": {"precision": prec and round(prec, 4), "recall": rec and round(rec, 4), "false_positive_rate": round(fp / (fp + tn), 4), "tp": tp, "fp": fp, "tn": tn, "fn": fn, "missed_kinds": errs},
         "crosscheck": {"inconsistent_detected": f"{inc_hit}/{inc_n}", "clean_false_alarms": f"{clean_alarm}/{clean_n}"},
         "processing_ms": {"median": round(times[len(times) // 2], 1), "p95": round(times[int(len(times) * .95)], 1), "max": round(times[-1], 1)},
         "caveats": "Synthetic, self-authored text templates; text input only (PDF/OCR path not measured); duplicates searched only within this dataset."}
    c.close(); shutil.rmtree(tmp, ignore_errors=True); return m


if __name__ == "__main__":
    if sys.argv[1:] == ["eval"]:
        m = evaluate(); json.dump(m, open(os.path.join(it.ROOT, "metrics.json"), "w"), indent=2); print(json.dumps(m, indent=2))
    else: print(__doc__)
