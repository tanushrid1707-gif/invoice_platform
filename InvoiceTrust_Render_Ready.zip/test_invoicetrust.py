import os, random, tempfile, unittest, json
from datetime import date, timedelta
import invoicetrust as it, synth


class T(unittest.TestCase):
    def setUp(self):
        d = tempfile.mkdtemp(); it.DB = os.path.join(d, "t.db"); it.STORE = os.path.join(d, "s"); it.init()
        self.r = random.Random(1); self.d = date(2026, 5, 1)

    def sub(self, **k):
        f, _, m = synth.build(self.r, k.pop("i", 1), synth.SELLERS[0], synth.BUYERS[0], k.pop("d", self.d), **k)
        return it.submit("acme", f), f, m

    def status(self, iid): return it.conn().execute("select status from inv where id=?", (iid,)).fetchone()[0]

    def test_valid_is_verified_with_simulated_offer(self):
        (i, st), _, _ = self.sub(t=0); self.assertEqual(st, "VERIFIED")
        self.assertTrue(json.loads(it.conn().execute("select reco from inv").fetchone()[0])["simulated"])

    def test_disguised_duplicate_flagged(self):
        (_, _), _, m = self.sub(t=0); f, _, _ = synth.disguise(self.r, 9, m)
        i, st = it.submit("acme", f); self.assertEqual(st, "NEEDS_REVIEW")
        self.assertTrue(any(d["flag"] for d in json.loads(it.conn().execute("select dups from inv where id=?", (i,)).fetchone()[0])))

    def test_exact_resubmission_blocked(self):
        _, f, _ = self.sub(t=0); self.assertEqual(it.submit("acme", f)[1], "BLOCKED_DUPLICATE")

    def test_delivery_mismatch_and_missing(self):
        (i, st), _, _ = self.sub(flaw="short_delivery"); self.assertEqual(st, "NEEDS_REVIEW")
        ch = json.loads(it.conn().execute("select checks from inv where id=?", (i,)).fetchone()[0])
        self.assertIn("delivery_quantity", [x["check"] for x in ch if x["status"] == "fail"])
        (_, st2), _, _ = self.sub(flaw="no_delivery", i=2); self.assertEqual(st2, "NEEDS_REVIEW")

    def test_recurring_order_not_flagged(self):
        _, _, m = self.sub(t=0); f, _, _ = synth.build(self.r, 5, m["seller"], m["buyer"], m["d"] + timedelta(days=30), items=m["items"])
        self.assertEqual(it.submit("acme", f)[1], "VERIFIED")

    def test_unknown_label_is_low_confidence_then_human_correction(self):
        (i, st), _, _ = self.sub(unknown_total=True); self.assertEqual(st, "NEEDS_REVIEW")
        it.api("POST", f"/api/invoice/{i}/correct", ("acme", "applicant"), {"fields": {"amount": "100000"}})
        self.assertIn(json.loads(it.conn().execute("select conf from inv where id=?", (i,)).fetchone()[0])["amount"], (1.0,))

    def test_tampered_document_fails_integrity(self):
        self.sub(t=0); self.assertTrue(it.verify()["all_ok"])
        p = it.conn().execute("select path from doc where kind='invoice'").fetchone()[0]
        open(p, "ab").write(b" ")
        v = it.verify(); self.assertFalse(v["all_ok"]); self.assertEqual([d["status"] for d in v["docs"]].count("MODIFIED"), 1)

    def test_ledger_edit_breaks_chain(self):
        self.sub(t=0); c = it.conn(); c.execute("update ledger set payload=replace(payload,'VERIFIED','APPROVED') where idx=(select max(idx) from ledger)"); c.commit()
        self.assertFalse(it.verify()["chain_ok"])

    def test_roles(self):
        (i, _), _, _ = self.sub(t=0); did = it.conn().execute("select id from doc limit 1").fetchone()[0]
        for who, path in [(("bolt", "applicant"), f"/api/invoice/{i}"), (("auditor1", "auditor"), f"/api/doc/{did}")]:
            with self.assertRaises(it.Err): it.api("GET", path, who, {})
        self.assertEqual(it.api("GET", f"/api/doc/{did}", ("lender1", "lender"), {})["kind"], "invoice")
        self.assertIsNone(it.api("GET", f"/api/invoice/{i}", ("auditor1", "auditor"), {})["amount"])

    def test_workflow_to_repayment(self):
        (i, _), _, _ = self.sub(t=0); L = ("lender1", "lender")
        it.api("POST", f"/api/invoice/{i}/disburse", L, {}); it.api("POST", f"/api/invoice/{i}/repay", ("acme", "applicant"), {"days_late": 2})
        self.assertEqual(self.status(i), "REPAID")


if __name__ == "__main__": unittest.main()
